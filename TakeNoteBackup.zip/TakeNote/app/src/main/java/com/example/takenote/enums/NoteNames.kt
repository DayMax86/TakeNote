package com.example.takenote.enums

enum class NoteNames {
    C, D, E, F, G, A, B,
}