package com.example.takenote.enums

object ComposableDestinations {
    const val SETTINGS = "settings"
    const val GAME = "game"
}